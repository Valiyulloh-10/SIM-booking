export default function ProjectPage() {
  return <div>Страница проекта</div>;
}